import React, { useState } from 'react';

export default function TeacherAlerts({ user }) {
  const [alerts, setAlerts] = useState([
    { id: 1, type: 'Mouvement suspect', etudiant: 'Aymon Ben Ali', place: 'B4', salle: 'A12', heure: '10:45', severity: 'high', status: 'nouvelle', videoUrl: '#' },
    { id: 2, type: 'Consultation non autorisée', etudiant: 'Sara Haddad', place: 'C2', salle: 'A12', heure: '10:32', severity: 'medium', status: 'nouvelle', videoUrl: '#' },
    { id: 3, type: 'Utilisation de téléphone', etudiant: 'Mehdi Kacem', place: 'D3', salle: 'A12', heure: '10:28', severity: 'high', status: 'traitee', videoUrl: '#' },
    { id: 4, type: 'Chuchotement répété', etudiant: 'Imen Trabelsi', place: 'A5', salle: 'A12', heure: '10:15', severity: 'medium', status: 'traitee', videoUrl: '#' }
  ]);

  const [filter, setFilter] = useState('tous');
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [comment, setComment] = useState('');

  const filteredAlerts = alerts.filter(a => filter === 'tous' || a.status === filter);

  const handleMarkAsTreated = (id) => {
    setAlerts(alerts.map(a => a.id === id ? { ...a, status: 'traitee' } : a));
    setSelectedAlert(null);
  };

  const getSeverityIcon = (severity) => severity === 'high' ? '🔴' : '🟠';

  return (
    <div className="teacher-alerts">
      {/* Filtres */}
      <div className="dashboard-section">
        <div className="section-header">
          <h3><i className="fas fa-filter"></i> Filtrer</h3>
          <div style={{ display: 'flex', gap: '8px' }}>
            {[
              { value: 'tous', label: 'Toutes', color: '#64748b' },
              { value: 'nouvelle', label: 'Nouvelles', color: '#ef4444' },
              { value: 'traitee', label: 'Traitées', color: '#10b981' }
            ].map(f => (
              <button
                key={f.value}
                onClick={() => setFilter(f.value)}
                style={{
                  padding: '6px 16px',
                  borderRadius: '20px',
                  border: 'none',
                  background: filter === f.value ? f.color : '#f1f5f9',
                  color: filter === f.value ? 'white' : '#475569',
                  cursor: 'pointer',
                  fontSize: '12px'
                }}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Liste des alertes */}
      <div className="dashboard-section">
        <div className="section-header">
          <h3><i className="fas fa-bell"></i> Alertes IA - Salle A12</h3>
        </div>
        
        {filteredAlerts.map(alert => (
          <div key={alert.id} style={{
            display: 'flex',
            alignItems: 'center',
            gap: '16px',
            padding: '16px',
            background: alert.status === 'nouvelle' ? '#fef2f2' : '#f8fafc',
            borderRadius: '12px',
            marginBottom: '12px',
            border: alert.status === 'nouvelle' ? '1px solid #fecaca' : '1px solid #e2e8f0'
          }}>
            <div style={{ fontSize: '24px' }}>{getSeverityIcon(alert.severity)}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700 }}>{alert.type}</div>
              <div style={{ fontSize: '13px', color: '#64748b' }}>
                {alert.etudiant} · Place {alert.place} · {alert.heure}
              </div>
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button 
                onClick={() => setSelectedAlert(alert)}
                style={{ background: '#eff6ff', border: 'none', padding: '6px 12px', borderRadius: '8px', cursor: 'pointer' }}
              >
                <i className="fas fa-eye"></i> Voir vidéo
              </button>
              {alert.status === 'nouvelle' && (
                <button 
                  onClick={() => handleMarkAsTreated(alert.id)}
                  style={{ background: '#ecfdf5', border: 'none', padding: '6px 12px', borderRadius: '8px', cursor: 'pointer', color: '#10b981' }}
                >
                  <i className="fas fa-check"></i> Traité
                </button>
              )}
              {alert.status === 'traitee' && (
                <span style={{ background: '#ecfdf5', padding: '6px 12px', borderRadius: '8px', fontSize: '12px', color: '#10b981' }}>
                  <i className="fas fa-check-circle"></i> Traitée
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Modal Vidéo */}
      {selectedAlert && (
        <div className="modal-overlay" onClick={() => setSelectedAlert(null)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Extrait vidéo - {selectedAlert.type}</h3>
              <button className="close" onClick={() => setSelectedAlert(null)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer' }}>✕</button>
            </div>
            <div className="modal-body">
              <div style={{ background: '#1e293b', borderRadius: '12px', padding: '20px', textAlign: 'center', marginBottom: '16px' }}>
                <i className="fas fa-video" style={{ fontSize: '48px', color: '#64748b', marginBottom: '12px', display: 'block' }}></i>
                <div style={{ color: 'white' }}>Vidéo de surveillance - Place {selectedAlert.place}</div>
                <div style={{ fontSize: '12px', color: '#94a3b8' }}>{selectedAlert.heure}</div>
              </div>
              <textarea 
                placeholder="Ajouter un commentaire..."
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                style={{ width: '100%', padding: '10px', border: '1px solid #e2e8f0', borderRadius: '8px', marginBottom: '16px', minHeight: '80px' }}
              />
              <button 
                onClick={() => { handleMarkAsTreated(selectedAlert.id); setComment(''); }}
                style={{ width: '100%', background: '#3b82f6', color: 'white', border: 'none', padding: '10px', borderRadius: '8px', cursor: 'pointer' }}
              >
                Valider et traiter
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}