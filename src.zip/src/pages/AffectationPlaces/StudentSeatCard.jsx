import React from "react";

export default function StudentSeatCard({ student, onClose }) {
  if (!student) {
    return (
      <div className="student-seat-card empty">
        <div className="empty-message">
          <i className="fas fa-user-circle"></i>
          <p>Sélectionnez un siège pour voir les détails de l'étudiant</p>
        </div>
      </div>
    );
  }

  const { student: etudiant, seatId, placeNumber, salle } = student;

  return (
    <div className="student-seat-card">
      <div className="card-header">
        <h3>
          <i className="fas fa-user-graduate"></i>
          Détails étudiant
        </h3>
        <button className="close-btn" onClick={onClose}>
          <i className="fas fa-times"></i>
        </button>
      </div>

      <div className="student-avatar-large">
        {etudiant.photo ? (
          <img src={etudiant.photo} alt={`${etudiant.prenom} ${etudiant.nom}`} />
        ) : (
          <div className="avatar-placeholder">
            {etudiant.prenom.charAt(0)}{etudiant.nom.charAt(0)}
          </div>
        )}
      </div>

      <div className="student-info">
        <h4>{etudiant.prenom} {etudiant.nom}</h4>
        <div className="student-id-badge">
          <i className="fas fa-id-card"></i>
          {etudiant.id}
        </div>
      </div>

      <div className="info-grid">
        <div className="info-row">
          <span className="info-label">
            <i className="fas fa-graduation-cap"></i> Niveau:
          </span>
          <span className="info-value">{etudiant.niveau}</span>
        </div>
        <div className="info-row">
          <span className="info-label">
            <i className="fas fa-code-branch"></i> Filière:
          </span>
          <span className="info-value">{etudiant.filiere}</span>
        </div>
        <div className="info-row">
          <span className="info-label">
            <i className="fas fa-users"></i> Groupe:
          </span>
          <span className="info-value">{etudiant.groupe}</span>
        </div>
        <div className="info-row">
          <span className="info-label">
            <i className="fas fa-envelope"></i> Email:
          </span>
          <span className="info-value">{etudiant.email || `${etudiant.prenom}.${etudiant.nom}@iit.tn`}</span>
        </div>
      </div>

      <div className="seat-info">
        <div className="seat-info-title">
          <i className="fas fa-chair"></i>
          Place attribuée
        </div>
        <div className="seat-details">
          <div className="seat-detail">
            <span className="detail-label">Salle:</span>
            <span className="detail-value">{salle}</span>
          </div>
          <div className="seat-detail">
            <span className="detail-label">Siège:</span>
            <span className="detail-value">{seatId}</span>
          </div>
          <div className="seat-detail">
            <span className="detail-label">N° Place:</span>
            <span className="detail-value">{placeNumber}</span>
          </div>
        </div>
      </div>

      <div className="qr-code">
        <div className="qr-placeholder">
          <i className="fas fa-qrcode"></i>
          <span>QR Code place</span>
        </div>
      </div>
    </div>
  );
}