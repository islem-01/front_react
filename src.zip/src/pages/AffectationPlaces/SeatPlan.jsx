import React from "react";

export default function SeatPlan({ room, onStudentSelect, selectedStudent }) {
  if (!room) {
    return (
      <div className="seat-plan-empty">
        <i className="fas fa-chair"></i>
        <p>Sélectionnez une salle pour voir le plan</p>
      </div>
    );
  }

  const { affectations, layout } = room;
  
  // Créer une map des affectations par siège
  const seatMap = {};
  affectations.forEach(aff => {
    seatMap[aff.seatId] = aff;
  });

  // Générer la grille des sièges
  const renderSeats = () => {
    const seats = [];
    const rows = layout.rows || 5;
    const cols = layout.cols || 6;
    
    for (let row = 0; row < rows; row++) {
      const rowSeats = [];
      for (let col = 0; col < cols; col++) {
        const seatId = `${String.fromCharCode(65 + row)}${col + 1}`;
        const affectation = seatMap[seatId];
        const isOccupied = !!affectation;
        const isSelected = selectedStudent && selectedStudent.seatId === seatId;
        
        rowSeats.push(
          <div
            key={`${row}-${col}`}
            className={`seat ${isOccupied ? 'occupied' : 'free'} ${isSelected ? 'selected' : ''}`}
            onClick={() => isOccupied && onStudentSelect(affectation)}
          >
            <div className="seat-label">{seatId}</div>
            {isOccupied && (
              <div className="seat-student">
                <div className="seat-student-avatar">
                  {affectation.student.prenom.charAt(0)}
                  {affectation.student.nom.charAt(0)}
                </div>
              </div>
            )}
            {!isOccupied && (
              <div className="seat-empty-icon">
                <i className="fas fa-chair"></i>
              </div>
            )}
          </div>
        );
      }
      seats.push(
        <div key={`row-${row}`} className="seat-row">
          <div className="seat-row-label">{String.fromCharCode(65 + row)}</div>
          <div className="seat-row-seats">{rowSeats}</div>
        </div>
      );
    }
    return seats;
  };

  return (
    <div className="seat-plan">
      <div className="seat-plan-header">
        <div className="room-title">
          <i className="fas fa-door-open"></i>
          <span>{room.room}</span>
          <span className="room-capacity-badge">
            {room.allocated} / {room.capacity} places
          </span>
        </div>
        <div className="legend">
          <div className="legend-item">
            <div className="legend-color occupied"></div>
            <span>Occupé</span>
          </div>
          <div className="legend-item">
            <div className="legend-color free"></div>
            <span>Libre</span>
          </div>
          <div className="legend-item">
            <div className="legend-color selected"></div>
            <span>Sélectionné</span>
          </div>
        </div>
      </div>

      <div className="seat-plan-grid">
        {/* Tableau */}
        <div className="whiteboard">
          <i className="fas fa-chalkboard"></i>
          <span>Tableau</span>
        </div>
        
        {/* Sièges */}
        <div className="seats-container">
          {renderSeats()}
        </div>
        
        {/* Bureau surveillant */}
        <div className="supervisor-desk">
          <i className="fas fa-desktop"></i>
          <span>Bureau surveillant</span>
        </div>
      </div>
    </div>
  );
}