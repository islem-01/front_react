import React, { useState, useEffect } from "react";
import RoomSelector from "./RoomSelector";
import SeatPlan from "./SeatPlan";
import StudentSeatCard from "./StudentSeatCard";
import "./AffectationPlaces.css";

// Données mockées
const mockStudents = {
  "L1": {
    "Informatique": {
      "G1": [
        { id: "IIT2024001", nom: "Ben Ali", prenom: "Ahmed", photo: null, email: "ahmed.benali@iit.tn" },
        { id: "IIT2024002", nom: "Touati", prenom: "Sofia", photo: null, email: "sofia.touati@iit.tn" },
        { id: "IIT2024003", nom: "Khelil", prenom: "Yassine", photo: null, email: "yassine.khelil@iit.tn" },
        { id: "IIT2024004", nom: "Mansouri", prenom: "Nadia", photo: null, email: "nadia.mansouri@iit.tn" },
        { id: "IIT2024005", nom: "Saidi", prenom: "Karim", photo: null, email: "karim.saidi@iit.tn" },
      ],
      "G2": [
        { id: "IIT2024006", nom: "Hamdi", prenom: "Leila", photo: null, email: "leila.hamdi@iit.tn" },
        { id: "IIT2024007", nom: "Bouaziz", prenom: "Sami", photo: null, email: "sami.bouaziz@iit.tn" },
        { id: "IIT2024008", nom: "Gharbi", prenom: "Rim", photo: null, email: "rim.gharbi@iit.tn" },
        { id: "IIT2024009", nom: "Mekki", prenom: "Oussama", photo: null, email: "oussama.mekki@iit.tn" },
        { id: "IIT2024010", nom: "Ben Salem", prenom: "Ines", photo: null, email: "ines.bensalem@iit.tn" },
      ],
      "G3": [
        { id: "IIT2024011", nom: "Chaabane", prenom: "Mohamed", photo: null, email: "mohamed.chaabane@iit.tn" },
        { id: "IIT2024012", nom: "Jemaa", prenom: "Sarra", photo: null, email: "sarra.jemaa@iit.tn" },
        { id: "IIT2024013", nom: "Ferjani", prenom: "Amine", photo: null, email: "amine.ferjani@iit.tn" },
      ]
    }
  },
  "L2": {
    "Reseaux": {
      "G1": [
        { id: "IIT2024014", nom: "Ben Yahia", prenom: "Wassim", photo: null, email: "wassim.benyahia@iit.tn" },
        { id: "IIT2024015", nom: "Ayari", prenom: "Hela", photo: null, email: "hela.ayari@iit.tn" },
        { id: "IIT2024016", nom: "Ben Amor", prenom: "Fedi", photo: null, email: "fedi.benamor@iit.tn" },
      ]
    }
  },
  "M1": {
    "IA": {
      "G1": [
        { id: "IIT2024017", nom: "Zouari", prenom: "Mariem", photo: null, email: "mariem.zouari@iit.tn" },
        { id: "IIT2024018", nom: "Ben Hadj", prenom: "Ahmed", photo: null, email: "ahmed.benhadj@iit.tn" },
      ]
    }
  }
};

const mockRooms = [
  { 
    id: 1, 
    name: "Salle A101", 
    floor: "Étage 1", 
    capacity: 30, 
    hasLayout: true, 
    layout: { 
      rows: 6,
      cols: 5,
      seats: Array(30).fill().map((_, i) => ({ 
        seatId: `${String.fromCharCode(65 + Math.floor(i / 6))}${(i % 6) + 1}`,
        row: Math.floor(i / 6),
        col: i % 6
      })) 
    } 
  },
  { 
    id: 2, 
    name: "Salle B202", 
    floor: "Étage 2", 
    capacity: 25, 
    hasLayout: true, 
    layout: { 
      rows: 5,
      cols: 5,
      seats: Array(25).fill().map((_, i) => ({ 
        seatId: `${String.fromCharCode(65 + Math.floor(i / 5))}${(i % 5) + 1}`,
        row: Math.floor(i / 5),
        col: i % 5
      })) 
    } 
  },
  { 
    id: 3, 
    name: "Salle C105", 
    floor: "Étage 1", 
    capacity: 20, 
    hasLayout: true, 
    layout: { 
      rows: 4,
      cols: 5,
      seats: Array(20).fill().map((_, i) => ({ 
        seatId: `${String.fromCharCode(65 + Math.floor(i / 4))}${(i % 4) + 1}`,
        row: Math.floor(i / 4),
        col: i % 4
      })) 
    } 
  },
  { 
    id: 4, 
    name: "Amphi D", 
    floor: "RDC", 
    capacity: 50, 
    hasLayout: true, 
    layout: { 
      rows: 10,
      cols: 5,
      seats: Array(50).fill().map((_, i) => ({ 
        seatId: `${String.fromCharCode(65 + Math.floor(i / 10))}${(i % 10) + 1}`,
        row: Math.floor(i / 10),
        col: i % 10
      })) 
    } 
  },
];

export default function AffectationPlaces() {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  
  // Étape 1 - Sélection
  const [selectedNiveau, setSelectedNiveau] = useState("");
  const [selectedFiliere, setSelectedFiliere] = useState("");
  const [selectedGroupes, setSelectedGroupes] = useState([]);
  
  // Données disponibles
  const [niveaux, setNiveaux] = useState([]);
  const [filieres, setFilieres] = useState([]);
  const [groupes, setGroupes] = useState([]);
  const [totalEtudiants, setTotalEtudiants] = useState(0);
  const [studentsList, setStudentsList] = useState([]);
  
  // Étape 2 - Résultat affectation
  const [selectedRooms, setSelectedRooms] = useState([]);
  const [affectation, setAffectation] = useState(null);
  const [optimisation, setOptimisation] = useState(null);
  
  // Étape 3 - Visualisation
  const [currentRoomId, setCurrentRoomId] = useState(null);
  const [selectedStudent, setSelectedStudent] = useState(null);

  // Initialiser les niveaux disponibles
  useEffect(() => {
    const niveauxDispo = Object.keys(mockStudents);
    setNiveaux(niveauxDispo);
  }, []);

  // Mettre à jour les filières quand le niveau change
  useEffect(() => {
    if (selectedNiveau && mockStudents[selectedNiveau]) {
      const filieresDispo = Object.keys(mockStudents[selectedNiveau]);
      setFilieres(filieresDispo);
      setSelectedFiliere("");
      setSelectedGroupes([]);
      setGroupes([]);
    } else {
      setFilieres([]);
    }
  }, [selectedNiveau]);

  // Mettre à jour les groupes quand la filière change
  useEffect(() => {
    if (selectedNiveau && selectedFiliere && mockStudents[selectedNiveau]?.[selectedFiliere]) {
      const groupesDispo = Object.keys(mockStudents[selectedNiveau][selectedFiliere]);
      setGroupes(groupesDispo);
      setSelectedGroupes([]);
    } else {
      setGroupes([]);
    }
  }, [selectedNiveau, selectedFiliere]);

  // Calculer le nombre total d'étudiants
  useEffect(() => {
    if (selectedNiveau && selectedFiliere && selectedGroupes.length > 0) {
      let total = 0;
      const students = [];
      selectedGroupes.forEach(groupe => {
        const groupStudents = mockStudents[selectedNiveau]?.[selectedFiliere]?.[groupe] || [];
        total += groupStudents.length;
        students.push(...groupStudents.map(s => ({ ...s, groupe, filiere: selectedFiliere, niveau: selectedNiveau })));
      });
      setTotalEtudiants(total);
      setStudentsList(students);
    } else {
      setTotalEtudiants(0);
      setStudentsList([]);
    }
  }, [selectedNiveau, selectedFiliere, selectedGroupes]);

  const toggleGroupe = (groupe) => {
    if (selectedGroupes.includes(groupe)) {
      setSelectedGroupes(selectedGroupes.filter(g => g !== groupe));
    } else {
      setSelectedGroupes([...selectedGroupes, groupe]);
    }
  };

  // Algorithme d'optimisation des salles
  const optimiserSalles = (nbEtudiants, sallesDisponibles) => {
    const sortedRooms = [...sallesDisponibles].sort((a, b) => a.capacity - b.capacity);
    
    let remaining = nbEtudiants;
    const selected = [];
    let totalCapacity = 0;
    
    while (remaining > 0 && sortedRooms.length > 0) {
      let bestIndex = -1;
      let bestWaste = Infinity;
      
      for (let i = 0; i < sortedRooms.length; i++) {
        if (sortedRooms[i].capacity >= remaining) {
          const waste = sortedRooms[i].capacity - remaining;
          if (waste < bestWaste) {
            bestWaste = waste;
            bestIndex = i;
          }
        }
      }
      
      if (bestIndex === -1) {
        bestIndex = sortedRooms.length - 1;
      }
      
      const selectedRoom = sortedRooms[bestIndex];
      selected.push({
        ...selectedRoom,
        allocatedStudents: Math.min(remaining, selectedRoom.capacity)
      });
      
      totalCapacity += selectedRoom.capacity;
      remaining -= selectedRoom.capacity;
      sortedRooms.splice(bestIndex, 1);
    }
    
    const wastedPlaces = totalCapacity - nbEtudiants;
    const utilisation = nbEtudiants > 0 ? Math.round((nbEtudiants / totalCapacity) * 100) : 0;
    
    return { selectedRooms: selected, utilisation, wastedPlaces, totalCapacity };
  };

  // Affecter les étudiants aux sièges
  const affecterEtudiants = (students, rooms) => {
    const shuffledStudents = [...students].sort(() => Math.random() - 0.5);
    
    let studentIndex = 0;
    const affectationParSalle = {};
    
    for (const room of rooms) {
      const seats = room.layout?.seats || [];
      const roomAffectations = [];
      
      for (let i = 0; i < room.allocatedStudents && studentIndex < shuffledStudents.length; i++) {
        const seat = seats[i % seats.length];
        roomAffectations.push({
          seatId: seat.seatId,
          seatRow: seat.row,
          seatCol: seat.col,
          student: shuffledStudents[studentIndex],
          salle: room.name,
          salleId: room.id,
          placeNumber: `${room.name.substring(room.name.length - 3)}-${seat.seatId}`
        });
        studentIndex++;
      }
      
      affectationParSalle[room.id] = {
        room: room.name,
        roomId: room.id,
        capacity: room.capacity,
        allocated: room.allocatedStudents,
        affectations: roomAffectations,
        layout: room.layout
      };
    }
    
    return affectationParSalle;
  };

  const handleGenererPlan = async () => {
    if (selectedGroupes.length === 0) {
      alert("Veuillez sélectionner au moins un groupe");
      return;
    }
    
    setLoading(true);
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const sallesDisponibles = mockRooms.filter(r => r.hasLayout);
    const optimisationResult = optimiserSalles(totalEtudiants, sallesDisponibles);
    setOptimisation(optimisationResult);
    setSelectedRooms(optimisationResult.selectedRooms);
    
    const affectationResult = affecterEtudiants(studentsList, optimisationResult.selectedRooms);
    setAffectation(affectationResult);
    
    setLoading(false);
    setStep(2);
  };

  const handleValiderAffectation = () => {
    const firstRoomId = Object.keys(affectation)[0];
    setCurrentRoomId(parseInt(firstRoomId));
    setStep(3);
  };

  const handleReinitialiser = () => {
    setStep(1);
    setSelectedNiveau("");
    setSelectedFiliere("");
    setSelectedGroupes([]);
    setAffectation(null);
    setOptimisation(null);
    setCurrentRoomId(null);
    setSelectedStudent(null);
  };

  const handleRoomChange = (roomId) => {
    setCurrentRoomId(roomId);
    setSelectedStudent(null);
  };

  const handleStudentSelect = (student) => {
    setSelectedStudent(student);
  };

  const currentRoom = currentRoomId && affectation ? affectation[currentRoomId] : null;
  const roomIds = affectation ? Object.keys(affectation).map(Number) : [];

  return (
    <div className="affectation-container">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

      {/* Header */}
      <div className="affectation-header">
        <div>
          <h1>Affectation des places</h1>
          <p>Planification intelligente et attribution automatique des sièges</p>
        </div>
        {step > 1 && (
          <button className="reset-btn" onClick={handleReinitialiser}>
            <i className="fas fa-plus"></i>
            Nouvelle affectation
          </button>
        )}
      </div>

      {/* Steps */}
      <div className="steps-indicator">
        <div className={`step ${step >= 1 ? 'active' : ''}`}>
          <div className="step-number">1</div>
          <div className="step-label">Sélection</div>
        </div>
        <div className="step-line"></div>
        <div className={`step ${step >= 2 ? 'active' : ''}`}>
          <div className="step-number">2</div>
          <div className="step-label">Optimisation</div>
        </div>
        <div className="step-line"></div>
        <div className={`step ${step >= 3 ? 'active' : ''}`}>
          <div className="step-number">3</div>
          <div className="step-label">Visualisation</div>
        </div>
      </div>

      {/* Step 1 - Selection */}
      {step === 1 && (
        <div className="selection-panel">
          <div className="selection-grid">
            <div className="selection-card">
              <div className="card-icon blue">
                <i className="fas fa-graduation-cap"></i>
              </div>
              <h3>Niveau</h3>
              <div className="options-list">
                {niveaux.map(niveau => (
                  <button
                    key={niveau}
                    className={`option-btn ${selectedNiveau === niveau ? 'selected' : ''}`}
                    onClick={() => setSelectedNiveau(niveau)}
                  >
                    {niveau}
                  </button>
                ))}
              </div>
            </div>

            <div className="selection-card">
              <div className="card-icon green">
                <i className="fas fa-code-branch"></i>
              </div>
              <h3>Filière</h3>
              <div className="options-list">
                {filieres.map(filiere => (
                  <button
                    key={filiere}
                    className={`option-btn ${selectedFiliere === filiere ? 'selected' : ''}`}
                    onClick={() => setSelectedFiliere(filiere)}
                    disabled={!selectedNiveau}
                  >
                    {filiere}
                  </button>
                ))}
              </div>
            </div>

            <div className="selection-card">
              <div className="card-icon orange">
                <i className="fas fa-users"></i>
              </div>
              <h3>Groupes</h3>
              <div className="options-list">
                {groupes.map(groupe => (
                  <button
                    key={groupe}
                    className={`option-btn ${selectedGroupes.includes(groupe) ? 'selected' : ''}`}
                    onClick={() => toggleGroupe(groupe)}
                    disabled={!selectedFiliere}
                  >
                    {groupe}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="summary-bar">
            <div className="summary-item">
              <i className="fas fa-users"></i>
              <span>{totalEtudiants} étudiant(s)</span>
            </div>
            <div className="summary-item">
              <i className="fas fa-layer-group"></i>
              <span>{selectedGroupes.length} groupe(s)</span>
            </div>
            <div className="summary-item">
              <i className="fas fa-chalkboard"></i>
              <span>{selectedNiveau || "—"} / {selectedFiliere || "—"}</span>
            </div>
            <button
              className="generate-btn"
              onClick={handleGenererPlan}
              disabled={selectedGroupes.length === 0 || loading}
            >
              {loading ? (
                <>
                  <div className="spinner-small"></div>
                  Calcul en cours...
                </>
              ) : (
                <>
                  <i className="fas fa-magic"></i>
                  Générer le plan
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Step 2 - Optimisation */}
      {step === 2 && optimisation && (
        <div className="optimisation-panel">
          <div className="optimisation-stats">
            <div className="opt-stat">
              <div className="opt-value">{totalEtudiants}</div>
              <div className="opt-label">Étudiants à placer</div>
            </div>
            <div className="opt-stat">
              <div className="opt-value">{optimisation.totalCapacity}</div>
              <div className="opt-label">Capacité totale</div>
            </div>
            <div className="opt-stat">
              <div className="opt-value">{optimisation.utilisation}%</div>
              <div className="opt-label">Taux d'utilisation</div>
            </div>
            <div className="opt-stat">
              <div className="opt-value">{optimisation.wastedPlaces}</div>
              <div className="opt-label">Places inutilisées</div>
            </div>
          </div>

          <div className="rooms-list">
            <h3>
              <i className="fas fa-door-open"></i>
              Salles sélectionnées
            </h3>
            <div className="rooms-grid-opt">
              {selectedRooms.map((room) => (
                <div key={room.id} className="room-card-opt">
                  <div className="room-header">
                    <span className="room-name">{room.name}</span>
                    <span className="room-capacity">{room.capacity} places</span>
                  </div>
                  <div className="room-details">
                    <div className="progress-bar">
                      <div
                        className="progress-fill"
                        style={{ width: `${(room.allocatedStudents / room.capacity) * 100}%` }}
                      ></div>
                    </div>
                    <div className="room-stats">
                      <span>
                        <i className="fas fa-user-check"></i> {room.allocatedStudents} affectés
                      </span>
                      <span>
                        <i className="fas fa-chair"></i> {room.capacity - room.allocatedStudents} libres
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="actions-buttons">
            <button className="btn-secondary" onClick={handleReinitialiser}>
              <i className="fas fa-undo"></i>
              Recommencer
            </button>
            <button className="btn-primary" onClick={handleValiderAffectation}>
              <i className="fas fa-check"></i>
              Valider l'affectation
            </button>
          </div>
        </div>
      )}

      {/* Step 3 - Visualisation */}
      {step === 3 && affectation && (
        <div className="visualisation-panel">
          <RoomSelector
            rooms={roomIds.map(id => affectation[id])}
            currentRoomId={currentRoomId}
            onRoomChange={handleRoomChange}
          />

          <div className="visualisation-content">
            <SeatPlan
              room={currentRoom}
              onStudentSelect={handleStudentSelect}
              selectedStudent={selectedStudent}
            />

            <StudentSeatCard
              student={selectedStudent}
              onClose={() => setSelectedStudent(null)}
            />
          </div>

          <div className="global-summary">
            <div className="summary-stats">
              <div className="sum-stat">
                <i className="fas fa-door-open"></i>
                <span>{Object.keys(affectation).length} salle(s)</span>
              </div>
              <div className="sum-stat">
                <i className="fas fa-user-check"></i>
                <span>{totalEtudiants} étudiant(s) affectés</span>
              </div>
              <div className="sum-stat">
                <i className="fas fa-chart-line"></i>
                <span>Taux d'utilisation: {optimisation?.utilisation}%</span>
              </div>
            </div>
            <button className="export-plan-btn">
              <i className="fas fa-download"></i>
              Exporter le plan
            </button>
          </div>
        </div>
      )}
    </div>
  );
}