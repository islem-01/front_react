import React from "react";

export default function RoomSelector({ rooms, currentRoomId, onRoomChange }) {
  return (
    <div className="room-selector">
      <div className="room-selector-header">
        <i className="fas fa-door-open"></i>
        <span>Salles configurées</span>
      </div>
      <div className="room-buttons">
        {rooms.map((room) => (
          <button
            key={room.roomId}
            className={`room-btn ${currentRoomId === room.roomId ? 'active' : ''}`}
            onClick={() => onRoomChange(room.roomId)}
          >
            <div className="room-btn-name">{room.room}</div>
            <div className="room-btn-stats">
              <span>{room.allocated} / {room.capacity}</span>
              <span className="room-btn-usage">
                {Math.round((room.allocated / room.capacity) * 100)}%
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}